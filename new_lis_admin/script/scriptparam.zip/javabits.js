   	  function changeMenu(theid)
   	  {
   	  	document.formsec.action = "./script/" + theid;
   	  	document.formsec.submit();
   	  }
